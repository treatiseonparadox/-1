package app.sport.workoutlog

import android.content.Intent
import android.media.MediaPlayer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatDelegate

    class MainActivity : AppCompatActivity() {
        private var counter: Int = 0
        private var stop: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO) //Выключаем темную тему
        setContentView(R.layout.activity_main)

        val m_activity = Intent(this@MainActivity, RegistrActivity::class.java)
        Thread {
            stop = true
            while (stop) {
                Thread.sleep(150)
                if (counter == 35)
                    stop = false
                counter++
                runOnUiThread {
                    if (counter == 30) startActivity(m_activity)
                }
            }
        }.start()
    }
}