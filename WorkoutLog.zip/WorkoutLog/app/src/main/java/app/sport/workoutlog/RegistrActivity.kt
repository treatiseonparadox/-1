package app.sport.workoutlog

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class RegistrActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registr)
    }
}